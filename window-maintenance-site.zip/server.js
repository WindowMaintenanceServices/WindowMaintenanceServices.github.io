const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
const PORT = 3000;
const GEMINI_API_KEY = 'YOUR_GEMINI_API_KEY'; // Replace with your real key

app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

app.post('/api/tip', async (req, res) => {
  const question = req.body.question;

  const prompt = `Provide a helpful and concise professional tip for window maintenance based on the following question: "${question}". Focus on practical advice.`;

  const payload = {
    contents: [
      {
        role: 'user',
        parts: [{ text: prompt }]
      }
    ]
  };

  try {
    const response = await fetch(\`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-pro:generateContent?key=\${GEMINI_API_KEY}\`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    const tip = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (tip) {
      res.json({ tip });
    } else {
      res.status(500).json({ error: 'No tip generated' });
    }
  } catch (err) {
    console.error('Error from Gemini API:', err);
    res.status(500).json({ error: 'Failed to fetch tip' });
  }
});

app.listen(PORT, () => {
  console.log(\`Proxy server running on http://localhost:\${PORT}\`);
});
