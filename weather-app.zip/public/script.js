async function getWeather() {
  const city = document.getElementById('cityInput').value;
  const response = await fetch(`/weather?city=${encodeURIComponent(city)}`);
  const data = await response.json();

  const weatherResult = document.getElementById('weatherResult');

  if (data.error) {
    weatherResult.textContent = `Error: ${data.error}`;
  } else {
    weatherResult.innerHTML = `
      <p><strong>${data.name}</strong></p>
      <p>${data.weather[0].description}</p>
      <p>Temperature: ${data.main.temp}°C</p>
    `;
  }
}
